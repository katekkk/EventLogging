package com.example.katek.eventlogging;

public class ListData {

    public String firstText;
    public String secondText;
    public String date;
    public String time;
    public String gps;
    public int index;
}
